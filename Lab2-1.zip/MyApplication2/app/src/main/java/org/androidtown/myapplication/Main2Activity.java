package org.androidtown.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class Main2Activity extends AppCompatActivity {

    Button btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        Intent passedIntent=getIntent();    //getIntent()로 Activity전환을 받음
        if(passedIntent!=null){
            String loginName=passedIntent.getStringExtra("loginName");
            String loginAge=passedIntent.getStringExtra("loginAge");
            Toast.makeText(getApplication(),"Student Info :"+loginName+","+loginAge,Toast.LENGTH_LONG).show();
        }

        btn = findViewById(R.id.btn);

        btn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                finish();
            }
        });
    }
}
