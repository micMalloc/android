package org.androidtown.myapplication;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class Main2Activity extends AppCompatActivity {

    TextView textView;
    Button goBtn;
    Button backBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        Intent passedIntent=getIntent();
        if(passedIntent!=null){
            String url=passedIntent.getStringExtra("Url");
            textView=(TextView)findViewById(R.id.textContent);
            textView.setText(url);
        }

        goBtn=(Button)findViewById(R.id.goBtn);
        backBtn=(Button)findViewById(R.id.backBtn);

        goBtn.setOnClickListener(new View.OnClickListener(){
           @Override
            public void onClick(View view){
                if(textView.getText().length()==0)
                    Toast.makeText(getApplication(), "주소를 다시 입력해주세요", Toast.LENGTH_LONG).show();
                else {
                    Intent intent=new Intent(Intent.ACTION_VIEW, Uri.parse("http://"+textView.getText()));
                    startActivity(intent);
                }
           }
        });
        backBtn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                Toast.makeText(getApplication(),"돌아가기버튼이 눌렸어요",Toast.LENGTH_LONG).show();

                Intent intent=new Intent();
                setResult(RESULT_OK,intent);
                finish();
            }
        });
    }
}
